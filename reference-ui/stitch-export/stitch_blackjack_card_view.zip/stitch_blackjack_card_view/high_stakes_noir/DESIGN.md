---
name: High Stakes Noir
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#bfc9c3'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#89938d'
  outline-variant: '#404944'
  surface-tint: '#95d3ba'
  primary: '#95d3ba'
  on-primary: '#003829'
  primary-container: '#064e3b'
  on-primary-container: '#80bea6'
  inverse-primary: '#2b6954'
  secondary: '#ffc640'
  on-secondary: '#402d00'
  secondary-container: '#e3aa00'
  on-secondary-container: '#5a4100'
  tertiary: '#c0c6db'
  on-tertiary: '#293040'
  tertiary-container: '#3d4455'
  on-tertiary-container: '#aab1c5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b0f0d6'
  primary-fixed-dim: '#95d3ba'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#0b513d'
  secondary-fixed: '#ffdf9f'
  secondary-fixed-dim: '#f9bd22'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#dce2f7'
  tertiary-fixed-dim: '#c0c6db'
  on-tertiary-fixed: '#141b2b'
  on-tertiary-fixed-variant: '#404758'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-gold:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  card-value:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
  bet-amount:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '700'
    lineHeight: '1'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  table-margin: 48px
  card-overlap: -40px
  gutter-md: 1.5rem
  safe-area: 2rem
---

## Brand & Style

The brand identity centers on the tension and sophistication of a high-stakes, private salon atmosphere. The target audience is discerning players who value exclusivity and precision. The emotional response should be one of "controlled adrenaline"—a mix of focus, luxury, and the gravity of large wagers.

The design system adopts a **Tactile / Skeuomorphic** style blended with **Minimalist** layout principles. It avoids the cluttered, flashing tropes of casual casinos in favor of deep-field depth, realistic textures (such as digital felt and brushed gold), and subtle ambient glows. The interface mimics physical objects—heavy clay chips, weighted cards, and inset brass detailing—to ground the digital experience in reality.

## Colors

The palette is anchored by **Deep Emerald (#064e3b)**, representing the traditional baize of a premium card table, but rendered with a gradient to suggest overhead spotlighting. **Charcoal (#111827)** provides the structural depth, used for the surrounding room and UI chrome. 

**Gold (#fbbf24)** is reserved strictly for interactive highlights, winning states, and high-value branding elements. For suit-specific logic:
- **Hearts & Diamonds:** Use a vibrant, high-contrast Red (#ef4444) to ensure readability against the green felt.
- **Spades & Clubs:** Use a crisp White (#f8fafc) rather than black, to maintain high visibility and a premium "monochrome" aesthetic against the dark background.

## Typography

This design system utilizes **Hanken Grotesk** for its sharp, contemporary corporate feel, ensuring all numerical data and game actions are legible at a glance. It provides a "Swiss-style" precision that contrasts beautifully with the tactile emerald background.

For technical data—such as "Table Min/Max" labels or real-time bet tallies—**JetBrains Mono** is used to evoke the feeling of a high-end digital readout, reinforcing the "calculated" nature of professional play. Headlines should be set with tight tracking to feel dense and impactful.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for the central "Table" area to ensure the geometry of the card dealing remains consistent across devices. A central focal point is maintained for the dealer's hand, with player positions fanning out in a semi-circle.

- **Desktop:** A wide-screen 12-column layout where the "Action Bar" (Hit, Stand, Double) is anchored to the bottom-center.
- **Mobile:** Reflows to a portrait-oriented "Top-Down" view. Cards are stacked with a vertical `card-overlap` to maximize screen real estate.
- **Spacing Rhythm:** Based on an 8px base unit. Margins are generous (`safe-area`) to prevent the UI from feeling "cheap" or crowded.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. The "Table" surface (Emerald) is the lowest z-index, featuring an inner shadow to look recessed into the Charcoal frame.

**Interactive Elements:**
- **Cards:** Use a multi-layered shadow; a sharp 2px shadow for the immediate edge and a soft 12px diffused shadow to suggest they are floating slightly above the felt.
- **Buttons:** Use a subtle top-down inner highlight (1px gold) to create a "beveled" look.
- **Glows:** Active states (like the "Current Turn" indicator) use a soft outer glow in Gold (#fbbf24) with a 20px blur and 30% opacity, suggesting a light source reflecting off the table surface.

## Shapes

The design system employs **Soft (0.25rem)** roundedness for standard UI elements like buttons and input fields to maintain a professional, architectural feel. 

However, specific game components deviate for realism:
- **Playing Cards:** Use a fixed `12px` corner radius to match standard physical decks.
- **Chips:** Always perfectly circular (Pill-shaped/Full Round) with concentric inner rings.
- **Action Buttons:** Use slightly more rounded corners (`0.5rem`) than the base system to make them feel "pressable" and distinct from informational panels.

## Components

### Action Buttons
Primary buttons (Hit, Double) feature a brushed metallic texture or a subtle vertical gradient. The "Stand" button should be treated as a secondary action with a Charcoal background and Gold border. All buttons use `label-mono` for text to emphasize the "utility" of the action.

### Playing Cards
The card component is a white container with a 1px inner border of #E2E8F0. The center features a ghosted watermark of the suit. Values are placed in the top-left and bottom-right corners using `card-value`.

### Betting Chips
Chips are circular components with a heavy "coin" edge (alternating light and dark segments). The color of the chip represents its denomination, but every chip must feature a gold-leaf center with the numerical value.

### Status Badges
Used for "Bust," "Blackjack," or "Push." These should be elevated above the cards with a frosted-glass (Glassmorphism) background, using a backdrop-blur of 8px to ensure the card values beneath remain visible but obscured.

### Table Headers
Labels like "DEALER STANDS ON 17" are etched directly into the felt using a darker shade of emerald with a "Letterpress" effect (1px light shadow below the text).