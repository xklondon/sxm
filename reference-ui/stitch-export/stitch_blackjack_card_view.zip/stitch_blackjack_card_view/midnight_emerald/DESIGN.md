---
name: Midnight Emerald
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#bfc9c3'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#89938d'
  outline-variant: '#404944'
  surface-tint: '#95d3ba'
  primary: '#95d3ba'
  on-primary: '#003829'
  primary-container: '#064e3b'
  on-primary-container: '#80bea6'
  inverse-primary: '#2b6954'
  secondary: '#ffc640'
  on-secondary: '#402d00'
  secondary-container: '#e3aa00'
  on-secondary-container: '#5a4100'
  tertiary: '#c0c6db'
  on-tertiary: '#293040'
  tertiary-container: '#3d4455'
  on-tertiary-container: '#aab1c5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b0f0d6'
  primary-fixed-dim: '#95d3ba'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#0b513d'
  secondary-fixed: '#ffdf9f'
  secondary-fixed-dim: '#f9bd22'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#dce2f7'
  tertiary-fixed-dim: '#c0c6db'
  on-tertiary-fixed: '#141b2b'
  on-tertiary-fixed-variant: '#404758'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-label:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-value:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
  button-text:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system targets a high-stakes, luxury digital environment. The brand personality is exclusive, sophisticated, and technically precise, evoking the atmosphere of a private high-roller lounge. 

The aesthetic blends **Minimalism** with **Tactile** accents. It utilizes deep, saturated tones and high-quality finishes to create a sense of value and permanence. Key characteristics include:
- **Depth through layering:** Subtle gradients and inner shadows create a sense of physical hardware.
- **Precision:** Clean typography and monospaced data points emphasize accuracy and fairness.
- **Lustrous Accents:** Gold is used sparingly as a "light source" to highlight wins, primary actions, and premium tiers.

## Colors

The palette is anchored in a deep, nocturnal foundation to ensure the interface recedes, allowing the gaming content to shine.

- **Primary (Emerald):** Used for key success states, active betting zones, and brand-critical touchpoints. It should feel rich and dark, not neon.
- **Secondary (Gold):** Reserved for luxury indicators, VIP status, currency values, and primary Call-to-Action (CTA) borders.
- **Tertiary (Deep Navy/Black):** The primary background color. Use variations in luminosity to separate the sidebar, header, and main stage.
- **Neutral (Slate):** Used for secondary text, inactive icons, and technical descriptions to maintain legibility without distracting from the primary action.

## Typography

Typography balances modern elegance with technical clarity. **Hanken Grotesk** provides a clean, contemporary feel for marketing and general UI navigation. **JetBrains Mono** is utilized for all "Live" data, odds, timers, and balances to convey a sense of a high-precision instrument and to ensure numbers remain legible even when updating rapidly.

Large display headings should use tighter letter spacing to feel more "custom," while data labels should be slightly tracked out for immediate scanning.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to maintain a sense of controlled, "physical" space, centering the gaming console within the viewport. 

- **Desktop:** 12-column grid, 1200px max-width, 24px gutters.
- **Tablet:** 8-column grid, fluid width, 20px margins.
- **Mobile:** 4-column grid, fluid width, 16px margins.

Spacing is calculated on a 4px baseline. Use wider spacing (MD/LG) for structural layout and tighter spacing (XS/SM) for internal component padding to maintain a "dense but organized" feeling similar to a physical casino table.

## Elevation & Depth

This design system uses **Tonal Layers** combined with **Low-contrast outlines** to simulate high-end materials.

1.  **Base (Level 0):** The deepest navy/black (#111827).
2.  **Surface (Level 1):** Slightly elevated panels used for game containers. These feature a 1px inner stroke of a lighter navy to create a "beveled" edge.
3.  **Interactive (Level 2):** Buttons and active cards. These use a dual-shadow technique: a sharp 1px top-highlight and a soft, diffused bottom-shadow with 40% opacity black.
4.  **Premium Accent:** 1px gold (#FBBF24) outlines are used exclusively for active states, VIP banners, or the "Winning" container.

## Shapes

The shape language is sophisticated and ergonomic. Standard UI cards and containers use a **0.5rem (8px)** corner radius to feel approachable yet structured. 

- **Interactive Elements:** Buttons and Input fields follow the `rounded-lg` (16px) or `rounded-xl` (24px) patterns to evoke the feeling of smooth, physical chips and gaming buttons.
- **Icons:** Should feature slightly rounded terminals to match the font weight of Hanken Grotesk.

## Components

- **Buttons:** Primary buttons use a subtle vertical gradient of Emerald (#064E3B). Secondary buttons are "Ghost" style with a thin Gold (#FBBF24) border and 10% gold fill on hover.
- **Casino Chips:** High-fidelity, circular components with radial gradients. Use **JetBrains Mono** for the value in the center.
- **Data Cards:** Use a dark tertiary background. Labels (JetBrains Mono) should be neutral slate, while values should be white or secondary gold.
- **Inputs:** Darker than the surface level, with a 1px border that glows Emerald when focused.
- **Progress Bars:** Thin, high-contrast lines. The track is dark navy; the fill is Emerald with a "glint" effect at the leading edge.
- **Badges/Chips (UI):** Small, pill-shaped labels for "Live," "High Stakes," or "Hot" games, using uppercase JetBrains Mono.